# RBSE: Back to Basics

Taking Rah's Bionics and Surgery Expansion back to the basics!  I love Rah. But I also love stupid pawns.  And stupid pawns need prostheses, too!

This mod expands on RBSE by creating an early research project which allows pawns to craft basic prostheses at a smithy.  Basic prostheses are worse than simple, but they make stupid pawns happy!  And, even though your stupid pawns haven't researched organ transplants, they can still try! Although the results are usually fatal, but why not try if that stupid pawn was going to die anyways??

Also, the research required for installing all prostheses will be reduced by 1 level.  Just because your stupid pawns don't quite know how to make a bionic arm, just yet, doesn't mean they won't attempt to install one!
